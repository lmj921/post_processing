﻿using UnityEngine;
using System.Collections.Generic;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Commando.AssetBundles
{
    // 是否需要改成Singleton?
    // 加载AB包，管理依赖关系
    // EDITOR下直接从ABSRC目录下加载
    // 目前采用同步加载的方式，支持DLC
    // 只在切换场景是unload不在需要的ab和其依赖ab
    // 支持AB设置成永远不释放

    /// <summary>
    /// https://confluence.ea.com/display/PC/Asset+Bundle+Solution
    /// </summary>
    public class AssetBundleManager : MonoBehaviour
    {
        static string m_BaseDownloadingURL = "";
        static string[] m_ActiveVariants = { };
        static AssetBundleManifest m_AssetBundleManifest = null;
        static string _streamAssetPath = null;
        #if UNITY_EDITOR
        const int kLoadFromABSRC = 1;
        const int kLoadFromAB = 2;
        static int m_LoadABType = -1;
        const string kLoadTypeInEditor = "loadTypeInEditor";
        public static string kEditorABSrcFolder = "ABSrc";
        #endif

        public static Dictionary<string, LoadedAssetBundle> m_LoadedMainAssetBundles = new Dictionary<string, LoadedAssetBundle>();
//所有加载主的ab，直接指定加载的ab，不包括依赖包
        public static Dictionary<string, LoadedAssetBundle> m_LoadedAssetBundles = new Dictionary<string, LoadedAssetBundle>();
//所有加载的ab，包括依赖包，可释放的
        static Dictionary<string, LoadedAssetBundle> m_PermanentAssetBundles = new Dictionary<string, LoadedAssetBundle>();

        static Dictionary<string, string> m_DownloadingErrors = new Dictionary<string, string>();
        //static List<AssetBundleLoadOperation> m_InProgressOperations = new List<AssetBundleLoadOperation> ();
        static Dictionary<string, string[]> m_Dependencies = new Dictionary<string, string[]>();
		
        // The base downloading url which is used to generate the full downloading url with the assetBundle names.
        public static string BaseDownloadingURL
        {
            get { return m_BaseDownloadingURL; }
            set { m_BaseDownloadingURL = value; }
        }
	
        // Variants which is used to define the active variants.
        public static string[] ActiveVariants
        {
            get { return m_ActiveVariants; }
            set { m_ActiveVariants = value; }
        }
	
        // AssetBundleManifest object which can be used to load the dependecies and check suitable assetBundle variants.
        public static AssetBundleManifest AssetBundleManifestObject
        {
            set { m_AssetBundleManifest = value; }
        }
			
	
        #if UNITY_EDITOR
        public static bool IsLoadFromABSRC()
        {
            if (m_LoadABType == -1)
                m_LoadABType = EditorPrefs.GetInt(kLoadTypeInEditor, kLoadFromABSRC);
            return m_LoadABType == kLoadFromABSRC ? true : false;
        }

        public static bool IsLoadFromAB()
        {
            if (m_LoadABType == -1)
                m_LoadABType = EditorPrefs.GetInt(kLoadTypeInEditor, kLoadFromABSRC);
            return m_LoadABType == kLoadFromAB ? true : false;
        }

        public static void SetLoadTypeABSRC()
        {
            if (m_LoadABType != kLoadFromABSRC)
            {
                EditorPrefs.SetInt(kLoadTypeInEditor, kLoadFromABSRC);
            }
            m_LoadABType = kLoadFromABSRC;
        }

        public static void SetLoadTypeAB()
        {
            if (m_LoadABType != kLoadFromAB)
            {
                EditorPrefs.SetInt(kLoadTypeInEditor, kLoadFromAB);
            }
            m_LoadABType = kLoadFromAB;
        }	
        #endif
	
        private static string GetStreamingAssetsPath()
        {
            if (string.IsNullOrEmpty(_streamAssetPath))                
            {
                _streamAssetPath = Application.streamingAssetsPath + "/" + AssetBundleUtility.GetPlatformName();
            }
            return _streamAssetPath;
        }

        public static void SetSourceAssetBundleDirectory(string relativePath)
        {
            BaseDownloadingURL = GetStreamingAssetsPath() + relativePath;
        }

        public static void SetSourceAssetBundleURL(string absolutePath)
        {
            BaseDownloadingURL = absolutePath + AssetBundleUtility.GetPlatformName() + "/";
        }

        /*
        public static void SetDevelopmentAssetBundleServer()
        {
            #if UNITY_EDITOR
            // If we're in Editor simulation mode, we don't have to setup a download URL
            //if (IsLoadFromABSRCInEditor)
            //	return;
            return;
            #endif
			
            TextAsset urlFile = Resources.Load("AssetBundleServerURL") as TextAsset;
            string url = (urlFile != null) ? urlFile.text.Trim() : null;
            if (url == null || url.Length == 0)
            {
                Debug.LogError("Development Server URL could not be found.");
                //AssetBundleManager.SetSourceAssetBundleURL("http://localhost:7888/" + UnityHelper.GetPlatformName() + "/");
            }
            else
            {
                AssetBundleManager.SetSourceAssetBundleURL(url);
            }
        }
        */
		
        // Get loaded AssetBundle, only return vaild object when all the dependencies are downloaded successfully.
        public static LoadedAssetBundle GetLoadedAssetBundle(string assetBundleName, out string error)
        {
            if (m_DownloadingErrors.TryGetValue(assetBundleName, out error))
                return null;
		
            LoadedAssetBundle bundle = null;
            m_LoadedAssetBundles.TryGetValue(assetBundleName, out bundle);
            if (bundle == null)
                return null;
			
            // No dependencies are recorded, only the bundle itself is required.
            string[] dependencies = null;
            if (!m_Dependencies.TryGetValue(assetBundleName, out dependencies))
                return bundle;
			
            // Make sure all dependencies are loaded
            foreach (var dependency in dependencies)
            {
                if (m_DownloadingErrors.TryGetValue(assetBundleName, out error))
                    return bundle;
	
                // Wait all the dependent assetBundles being loaded.
                LoadedAssetBundle dependentBundle;
                m_LoadedAssetBundles.TryGetValue(dependency, out dependentBundle);
                if (dependentBundle == null)
                    return null;
            }
	
            return bundle;
        }
	
	
        /// <summary>
        /// Initialize. Load AssetBundleManifest.
        /// </summary>
        public static void Initialize()
        {
            //TODO 判断是否是DLC
            string manifestAssetBundleName = AssetBundleUtility.GetPlatformName();

#if UNITY_EDITOR
            if (IsLoadFromABSRC())
            {
                return;
            }
#endif
            string path = GetStreamingAssetsPath() + "/" + manifestAssetBundleName;
            //获取所有ab的manifest
            AssetBundle manifestAb = AssetBundle.LoadFromFile(path);
            m_AssetBundleManifest = manifestAb.LoadAsset<AssetBundleManifest>("AssetBundleManifest");
        }

        /// <summary>
        /// 根据assetname，从AB里加载对应的asset，该方法是同步的
        /// </summary>
        /// <returns>The asset.</returns>
        /// <param name="assetBundleName">Asset bundle name.</param>
        /// <param name="assetName">Asset name.</param>
        /// <typeparam name="T">The 1st type parameter.</typeparam>
        public static T LoadAsset<T>(string assetBundleName, string assetName) where T:Object
        {
            //TODO 判断是否是DLC

            T asset;
#if UNITY_EDITOR
            if (IsLoadFromABSRC())
            {
                string[] arr = AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName(assetBundleName, assetName);//先从assetbundle里获取资源
                if (arr.Length == 0)
                {//没有设置assetbundle的资源，根据名字查找，这类资源必须去设置assetbundle name
                    //此段逻辑只用于editor下
                    string[] guidArr = AssetDatabase.FindAssets(assetName, new string[]{ "Assets/_Assets/AbSrc" });
                    string guidPath = AssetDatabase.GUIDToAssetPath(guidArr[0]);
                    asset = AssetDatabase.LoadAssetAtPath<T>(guidPath);

                    //AssetDatabase.ClearLabels(asset);
                    //AssetDatabase.SetLabels(asset,new string[]{"joker test"});
                }
                else
                {
                    asset = AssetDatabase.LoadAssetAtPath<T>(arr[0]);
                }
                    

                return asset;
            }
#endif
            AssetBundle ab = LoadABSmart(assetBundleName);
            asset = ab.LoadAsset<T>(assetName);           
            return asset;
        }

        public static T[] LoadAllAssets<T>(string assetBundleName) where T:Object
        {
            //TODO 判断是否是DLC
            #if UNITY_EDITOR
            if (IsLoadFromABSRC())
            {                
                string[] arr = AssetDatabase.GetAssetPathsFromAssetBundle(assetBundleName);;//先从assetbundle里获取资源
                List<T> assetList = new List<T>();
                for (int i = 0,max=arr.Length; i < max; i++) {
                    T temp=AssetDatabase.LoadAssetAtPath<T>(arr[i]);
                    assetList.Add(temp);
                }                    
                return assetList.ToArray();
            }
            #endif
            AssetBundle ab = LoadABSmart(assetBundleName);
            T[] assetArr = ab.LoadAllAssets<T>();           
            return assetArr;
        }

        /// <summary>
        /// Gets all asset names from asset bundle.
        /// </summary>
        /// <returns>The asset names from asset bundle.</returns>
        /// <param name="assetBundleName">Asset bundle name.</param>
        public static string[] GetAssetNamesFromAssetBundle(string assetBundleName)
        {
            AssetBundle ab = LoadABSmart(assetBundleName);
            return ab.GetAllAssetNames();
        }

        static AssetBundle LoadABSmart(string assetBundleName)
        {
            AssetBundle result = null;
            LoadedAssetBundle loadedAssetBundle = null;
            if (m_LoadedMainAssetBundles.TryGetValue(assetBundleName, out loadedAssetBundle))//判断assetBundle是否已经在main assetbundle，如果加载过了，直接从cache里获取
            
            {
                result = loadedAssetBundle.m_AssetBundle;
            }
            else
            {
                //加载依赖
                AssetBundleManager.LoadDependency(assetBundleName);
                result = DoLoadAB(assetBundleName);
                //加入到main assetbundle缓存
                m_LoadedMainAssetBundles.Add(assetBundleName, new LoadedAssetBundle(result));
            }
            return result;
        }

        public static void UnloadMainAssetBundle(string assetBundleName)
        {
            //Debug.Log("start unload main=" + assetBundleName);
            string[] dependencyArr = m_AssetBundleManifest.GetAllDependencies(assetBundleName);
            if (dependencyArr.Length > 0)
            {
                for (int i = 0, n = dependencyArr.Length; i < n; i++)
                {
                    string dependencyName = dependencyArr[i];
                    DoUnloadAB(dependencyName);
                    //Debug.Log("unload dependency=" + dependencyName);
                }
            }

            DoUnloadAB(assetBundleName);
            m_LoadedMainAssetBundles.Remove(assetBundleName);
            //Debug.Log("end unload main=" + assetBundleName);

            m_Dependencies.Remove(assetBundleName);
        }

        public static void UnloadAllMainAssetBundle()
        {
            //Dictionary<string, LoadedAssetBundle>.Enumerator etor = m_LoadedMainAssetBundles.GetEnumerator();
            //while (etor.MoveNext())
            //{
            //    UnloadMainAssetBundle(etor.Current.Key);
            //}

            //copy一份keys，因为在unload方法里，需要操作dictionary
            List<string> list = new List<string>(m_LoadedMainAssetBundles.Keys);
            for (int i = 0, n = list.Count; i < n; i++)
            {
                UnloadMainAssetBundle(list[i]);
            }
        }

        static void LoadDependency(string assetBundleName)
        {
            if (m_AssetBundleManifest == null)
            {
                return;
            }

            string[] dependencyArr = m_AssetBundleManifest.GetAllDependencies(assetBundleName);
            if (dependencyArr.Length == 0)
            {
                return;
            }

            //额外保存一份ab dependency的关系，最后可能不需要
            m_Dependencies.Add(assetBundleName, dependencyArr);

            //load dependency
            for (int i = 0; i < dependencyArr.Length; i++)
            {
                string abName = dependencyArr[i];
                DoLoadAB(abName);
            }
        }

        static void DoUnloadAB(string assetBundleName, bool isPermanent = false)
        {
            LoadedAssetBundle loadedAssetBundle = null;
            if (m_LoadedAssetBundles.TryGetValue(assetBundleName, out loadedAssetBundle))//判断assetBundle是否已经被加载过，如果加载过了，则需要reference out++
            {
                loadedAssetBundle.m_ReferencedCount--;
                if (loadedAssetBundle.m_ReferencedCount <= 0)// 释放
                {
                    loadedAssetBundle.m_AssetBundle.Unload(false);
                    m_LoadedAssetBundles.Remove(assetBundleName);                    
                }
            }
        }

        //真的从存储上加载AB，如果该AB已经加载过，则需要reference count++，这种情况主要是在相互依赖的情况下发生的
        //非依赖情况，不会反复进入这个方法，在上层已经被判断掉了
        static AssetBundle DoLoadAB(string assetBundleName, bool isPermanent = false)
        {
            LoadedAssetBundle loadedAssetBundle = null;
            if (m_LoadedAssetBundles.TryGetValue(assetBundleName, out loadedAssetBundle))//判断assetBundle是否已经被加载过，如果加载过了，则需要reference out++
            {
                loadedAssetBundle.m_ReferencedCount++;
                return loadedAssetBundle.m_AssetBundle;
            }

            string dependencyPath = GetStreamingAssetsPath() + "/" + assetBundleName;
            AssetBundle ab = AssetBundle.LoadFromFile(dependencyPath);
            m_LoadedAssetBundles.Add(assetBundleName, new LoadedAssetBundle(ab));
            return ab;
        }

    }
    // End of AssetBundleManager.
}