﻿using System.Collections.Generic;
using System;

namespace Commando.AssetBundles
{
    [Serializable]
    public class ABMappingList
    {
        public List<ABMapping> mappingList = new List<ABMapping> ();
    }

    [Serializable]
    public class ABMapping
    {
        public string assetName;//同prefabName，可能还会有mat，tex，audio等
        public string assetType;
        public string assetBundleName;
        public int initCount;
        public int maxCount;
    }
}