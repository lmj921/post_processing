﻿namespace Commando.Res
{
    public class NullResourceManager : ResourceManager
    {
        public NullResourceManager()
        {

        }
    }
}