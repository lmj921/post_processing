﻿using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace Commando.Res
{
    /// <summary>
    /// parse the reload rules json file to generate and merge
    /// https://confluence.ea.com/display/PC/Preload+and+Pool+Manager#PreloadandPoolManager-FindPreloadRes
    /// </summary>
    public static class FindPreloadRes
    {
        private static readonly string GeneratePreloadFilenameHeader= @"// this file is generated and can also be merged with edited version
// please visit https://confluence.ea.com/display/PC/Preload+and+Pool+Manager#PreloadandPoolManager-FindPreloadRes 
// for more information
//
";
        public static readonly string JsonDefinitionDirectory = Application.dataPath + "/_Assets/ABSrc/config/";

        public static readonly string PreloadJsonFilename = Application.dataPath + "/Commando/ResourceManager/PoolManager/Editor/FindPreloadResRules.json";
        public static readonly string GeneratePreloadFilename = JsonDefinitionDirectory + "/other_config/preload_config_json.bytes";

        private delegate void ReadFilesCallback(string filename,object obj);

        [MenuItem("Commando/Config/Generate Preload Config")]
        public static void FindUnitPreload()
        {
            Rules rules = JsonHelper.DeserializeObject<Rules>((new Regex("//.*")).Replace(File.ReadAllText(PreloadJsonFilename),""));
            PreloadConfig parsed = ParseRules(rules);
            PreloadConfig former = PreloadConfig.Deserialize(File.ReadAllText(GeneratePreloadFilename));
            MergeAutoPreload(parsed, former);

            string json = GeneratePreloadFilenameHeader + former.Serialize();
            File.WriteAllText(GeneratePreloadFilename,json);

            EditorUtility.DisplayDialog("Successful!", "Read find preload resource and merge done!","OK");
        }

        private static void MergeAutoPreload(PreloadConfig parsed,PreloadConfig original)
        {
            parsed.Unit.ForEach(parsedUnit =>
            {
                PreloadUnit origUnit = original.Unit.Find(u => u.SrcFile.Equals(parsedUnit.SrcFile) && u.UnitId == parsedUnit.UnitId);
                if (origUnit != null)
                {
                    parsedUnit.AutoPreloadList.ForEach(parsedList => 
                    {
                        PreloadUnitList origList = origUnit.AutoPreloadList.Find(du => du.Name.Equals(parsedList.Name));
                        if (origList != null)
                        {
                            parsedList.InstantiateCount = Mathf.Max(1, origList.InstantiateCount);
                        }                        
                    });
                    
                    parsedUnit.ManualPreloadList = origUnit.ManualPreloadList;
                }
            });

            original.Unit = parsed.Unit;
        }

        private static PreloadConfig ParseRules(Rules rules)
        {
            PreloadConfig config = new PreloadConfig { Unit = new List<PreloadUnit>()};
            foreach (var r in rules.MainRules)
            {
                ReadFiles(r.ParseFile,(filename,obj) =>
                {
                    UnitDefinition def = obj as UnitDefinition;
                    if (def == null)
                    {
                        throw new Exception("Currently, cannot support parse a non-UnitDefinition class file in MainRules");
                    }

                    PreloadUnit unit = new PreloadUnit { SrcFile = filename, UnitId = def.UnitId,AutoPreloadList = new List<PreloadUnitList>()};
                    
                    List<string> res = new List<string>();
                    r.Search.ForEach(i => i.Parse(obj, rules, res));

                    res.ForEach(item =>
                        unit.AutoPreloadList.Add(new PreloadUnitList { Name = item, InstantiateCount = 1})
                    );

                    config.Unit.Add(unit);
                });
            }

            return config;
        }


        private static void LoadFiles(List<FileInfo> files, DirectoryInfo dir)
        {
            files.AddRange(dir.GetFiles());
            files.RemoveAll(f => f.Name.EndsWith(".meta"));

            foreach(var d in dir.GetDirectories())
            {
                LoadFiles(files, d);
            }
        }
        private static List<object> ReadFiles(ParseFileType parse, ReadFilesCallback cb = null)
        {
            Type ty = Type.GetType(parse.Type + ", Assembly-CSharp");
            if (ty == null)
            {
                throw new Exception("cannot find the type :" + parse.Type);
            }

            List<object> list = new List<object>();

            DirectoryInfo dir = new DirectoryInfo(JsonDefinitionDirectory);
            List<FileInfo> files = new List<FileInfo>();
            LoadFiles(files, dir);
            
            parse.Files.ForEach(p =>
            {
                files.ForEach(f =>
                {
                    if (Regex.IsMatch(f.Name, p))
                    {
                        object obj = JsonHelper.DeserializeObject(File.ReadAllText(f.FullName), ty);
                        list.Add(obj);

                        if (cb != null)
                        {
                            cb(f.Name,obj);
                        }
                    }
                });
            });

            return list;
        }

        private class ParseFileType
        {
            public List<string> Files = null;
            public string Type = null;
        }

        private class Rules
        {
            public List<SearchRule> SubRules = null;
            public List<SearchRule> MainRules = null; 

            internal SearchRule FindSub(string name)
            {
                return SubRules.Find(r => r.Name.Equals(name));
            }
        }

        private class SearchRule
        {
            public string Name = null;
            public string Sub = null;
            public string FilterId = null;
            public string FilterObj = null;

            public string Field = null;
            public string Linked = null;
            public ParseFileType ParseFile = null;
            public List<SearchRule> Search = null;
            
            public void Parse(object obj, Rules rules,List<string> res,IList filters = null)
            {
                if (string.IsNullOrEmpty(Field))
                {
                    List<object> objs = ReadFiles(ParseFile);
                    objs.ForEach(o =>
                    {
                        Search.ForEach(i => i.Parse(o, rules, res));
                    });
                }
                else
                {
                    FieldInfo fi = obj.GetType().GetField(Field);
                    if(fi == null)
                    {
                        // error
                        throw new Exception("cannot find the From:" + Field);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(Sub))
                        {
                            SearchRule pr = rules.FindSub(Sub);
                            if (pr == null)
                            {
                                throw new Exception("cannot find the Sub:" + Sub);
                            }
                            pr.Field = Field;
                            pr.Parse(obj, rules, res);
                        }
                        else
                        {
                            if (fi.FieldType.IsGenericType && fi.FieldType.GetGenericTypeDefinition() == typeof(List<>))
                            {
                                // is a list

                                IList list = (IList)fi.GetValue(obj);
                                if (list != null && list.Count > 0)
                                {
                                    if (list[0] is int)
                                    {
                                        // is id list

                                        List<object> objs = ReadFiles(ParseFile);
                                        objs.ForEach(o =>
                                        {
                                            Search.ForEach(i => i.Parse(o, rules, res, list));
                                        });
                                    }
                                    else
                                    {
                                        // is object list

                                        foreach (var o in list)
                                        {
                                            if (!string.IsNullOrEmpty(FilterObj) && !o.GetType().Name.Equals(FilterObj))
                                            {
                                                continue;
                                            }

                                            if (!string.IsNullOrEmpty(FilterId))
                                            {
                                                if (filters == null)
                                                {
                                                    throw new Exception("the parent node must be id list with FilterId" + FilterId);
                                                }

                                                FieldInfo id = o.GetType().GetField(FilterId);
                                                if(id == null)
                                                {
                                                    throw new Exception("cannot find the FilterId:" + FilterId + " in " + o.GetType());
                                                }

                                                if (id.FieldType != typeof(int))
                                                {
                                                    throw new Exception("FilterId:" + FilterId + " must be a int field");
                                                }

                                                if (!filters.Contains((int)id.GetValue(o)))
                                                {
                                                    continue;
                                                }
                                            }
                                            else
                                            {
                                                if (filters != null)
                                                {
                                                    throw new Exception("the parent node must be id list with FilterId" + FilterId);
                                                }
                                            }
                                            
                                            Search.ForEach(i => i.Parse(o, rules, res));
                                        }
                                    }
                                }
                            }
                            else if (fi.FieldType == typeof(string))
                            {
                                // is string
                                string resName = (string)fi.GetValue(obj);
                                if (!string.IsNullOrEmpty(resName) && !res.Contains(resName))
                                {
                                    res.Add(resName);
                                }                                
                            }
                            else if (fi.FieldType == typeof(int))
                            {
                                // is int
                                if (ParseFile == null)
                                {
                                    throw new Exception("Please set ParseFile with int field " + Field);
                                }

                                List<int> list = new List<int>();
                                list.Add((int)fi.GetValue(obj));

                                List<object> objs = ReadFiles(ParseFile);
                                objs.ForEach(o =>
                                {
                                    Search.ForEach(i => i.Parse(o, rules, res, list));
                                });
                            }
                            else
                            {
                                // is a object
                                object o = fi.GetValue(obj);
                                Search.ForEach(i => i.Parse(o, rules, res));
                            }
                        }                        
                    }
                }                
            }
        }
    }
}
