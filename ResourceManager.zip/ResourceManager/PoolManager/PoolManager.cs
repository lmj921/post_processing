﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Entitas.VisualDebugging.Unity;

namespace Commando.Res
{
    /// <summary>
    /// https://confluence.ea.com/display/PC/Preload+and+Pool+Manager
    /// </summary>
    public class PoolManager : IEnumerable<KeyValuePair<string, GameObjectPool>>
    {
        public static readonly Type IPoolObjectMonoType = typeof(IPoolObjectMono);

        public delegate GameObject LoadAssetsDelegate(string name);

        private readonly LoadAssetsDelegate _loadAsset;
        private readonly SortedDictionary<string, GameObjectPool> _pools = new SortedDictionary<string, GameObjectPool>();
        private readonly Transform _poolRoot;

        public delegate void PoolChangeCallback();

        public Transform RootNode
        {
            get { return _poolRoot; }
        }

        public int PoolsCount
        {
            get { return _pools.Count; }
        }

        private PoolChangeCallback _poolChangeEvt;

        public PoolManager(LoadAssetsDelegate load, string name)
        {
            _loadAsset = load;
            _poolRoot = (new GameObject("PoolManager_" + name)).transform;
            _poolRoot.gameObject.AddComponent<PoolManagerMono>().pool = this;

            if (Application.isPlaying)
            {
                GameObject.DontDestroyOnLoad(_poolRoot);
            }
        }

        public void SetPoolChangeCallback(PoolChangeCallback cb)
        {
            _poolChangeEvt = cb;
        }
        /// <summary>
        /// add a prefab into pool
        /// </summary>
        /// <param name="name"></param>
        /// <param name="asset"></param>
        /// <param name="instantiateCount"></param>
        public void AddPrefab(string name, GameObject asset, int instantiateCount = 1)
        {
            #if UNITY_EDITOR
            if (asset==null) {
                CLog.Error("Asset is null (" +name +"). Please check asset name.", ChannelType.Puppet);
            }

            #endif

            var goPool = GetGoPool(name);
            instantiateCount = Mathf.Max(instantiateCount, 1);
            for (int i = 0; i < instantiateCount; i++)
            {
                GameObject go = GameObject.Instantiate<GameObject>(asset);
                this.AddGameObject(goPool, go);
#if UNITY_EDITOR
                go.AddComponent<PoolObjMonoChecker>();
#endif
            }

            if (_poolChangeEvt != null)
            {
                _poolChangeEvt();
            }
        }            

        public void AddGameObject(string name, GameObject go)
        {
            var goPool = GetGoPool(name);

            this.AddGameObject(goPool, go);
        }

        public GameObjectPool GetGoPool(string name)
        {
            GameObjectPool goPool;
            if (_pools.ContainsKey(name))
            {
                goPool = _pools[name];
            }
            else
            {
                goPool = new GameObjectPool(name, _poolRoot);
                _pools.Add(name, goPool);
            }
            return goPool;
        }

        public GameObjectPool GetGoPoolNoCreate(string name)
        {
            GameObjectPool goPool = null;
            if (_pools.ContainsKey(name))
            {
                goPool = _pools[name];
            }

            return goPool;
        }

        private void AddGameObject(GameObjectPool goPool, GameObject go)
        {
            go.transform.SetParent(goPool.ParentNode, false);
            goPool.Cached.Add(new PoolObj(go));
            go.SetActive(false);
        }

        /// <summary>
        /// fetach a prefab instance 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public GameObject Fetch(string name)
        {
            if (_poolChangeEvt != null)
            {
                _poolChangeEvt();
            }

            if (_pools.ContainsKey(name))
            {
                return _pools[name].Fetch();
            }
            else
            {
                CLog.Warning("Should add [" + name + "] to preload pool manager. Run 'Commando/Config/Generate Preload Config' command would be helpful.");
                AddPrefab(name, _loadAsset(name));

                return Fetch(name);
            }
        }

        /// <summary>
        /// release a prefab instance which fetch from this pool
        /// </summary>
        /// <param name="obj"></param>
        public void Release(GameObject objInstance)
        {
            if (_poolChangeEvt != null)
            {
                _poolChangeEvt();
            }
            
            foreach (var kv in _pools)
            {
                PoolObj po = kv.Value.Allocated.Find(o => o.gameObject == objInstance);
                if (po != null)
                {
                    kv.Value.Release(po);
                    return;
                }
            }                      

            CLog.Error("Cannot release [" + objInstance + "] which not in pool");
        }
        
        /// <summary>
        /// clear and destroy all prefab instances include allocated
        /// </summary>
        public void DestroyAll()
        {
            foreach (var kv in _pools)
            {
                kv.Value.Destroy();
            }
            _pools.Clear();

            if (_poolRoot != null && _poolChangeEvt != null)
            {
                _poolChangeEvt();
            }
        }

        public GameObjectPool this[string key]
        {
            get { return _pools[key]; }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _pools.GetEnumerator();
        }

        IEnumerator<KeyValuePair<string, GameObjectPool>> IEnumerable<KeyValuePair<string, GameObjectPool>>.GetEnumerator()
        {
            return _pools.GetEnumerator();
        }
    }

    /// <summary>
    /// pool object management class, it will clear status for some components while reseting
    /// such as :
    /// TrailRenderer
    /// Animator
    /// ...
    /// we don't call GetComponentsInChildren in each PoolManager.Release, because of this function is heavy for performance:
    /// https://confluence.ea.com/display/PC/Preload+and+Pool+Manager#PreloadandPoolManager-PoolObj
    /// </summary>
    public class PoolObj
    {
        private readonly TrailRenderer[] _trails;
        private readonly Animator[] _animators;
        private readonly Animation[] _animations;
        private readonly List<MonoBehaviour> _resetMonos = new List<MonoBehaviour>();

        public Transform transform
        {
            get { return gameObject.transform; }
        }

        public GameObject gameObject
        {
            get;
            private set;
        }

        public PoolObj(GameObject go)
        {
            gameObject = go;

            _trails = gameObject.GetComponentsInChildren<TrailRenderer>(true);
            _animators = gameObject.GetComponentsInChildren<Animator>(true);
            _animations = gameObject.GetComponentsInChildren<Animation>(true);

            gameObject.GetComponents(_resetMonos);
            _resetMonos.RemoveAll(m => !(PoolManager.IPoolObjectMonoType.IsAssignableFrom(m.GetType())));
        }

        public void Reset()
        {
            Array.ForEach(_trails, tr => tr.Clear());
            Array.ForEach(_animators, an => an.Rebind());
            Array.ForEach(_animations, an => an.Rewind());

            _resetMonos.ForEach(m => ((IPoolObjectMono)m).ResetPoolObj());
        }
    }

    public class GameObjectPool
    {
        private static readonly int DefaultCachedListCapability = 10;       

        private readonly string _name;
        public string Name
        {
            get { return _name; }
        }

        private Transform _parentNode;
        public Transform ParentNode
        {
            get { return _parentNode; }
        }

        private readonly List<PoolObj> _cached = new List<PoolObj>(DefaultCachedListCapability);
        private readonly List<PoolObj> _allocated = new List<PoolObj>(DefaultCachedListCapability);

        public List<PoolObj> Cached
        {
            get { return _cached; }
        }
        
        public List<PoolObj> Allocated
        {
            get { return _allocated; }
        }

        public GameObjectPool(string name, Transform root)
        {
            _name = name;
            _parentNode = (new GameObject("pools_" + name)).transform;
            _parentNode.SetParent(root, false);
            _parentNode.gameObject.SetActive(false);
        }
        
        public GameObject Fetch()
        {
            PoolObj po;
            if (Cached.Count > 0)
            {
                po = Cached[0];
                Cached.RemoveAt(0);
            }
            else
            {
                // clone a cached or allocated one to return it
                PoolObj template = Cached.Count > 0 ? Cached[0] : Allocated[0];
                po = new PoolObj((GameObject.Instantiate<GameObject>(template.gameObject)).gameObject);
            }

            Allocated.Add(po);
            po.Reset();

            po.transform.SetParent(null, false);
            po.gameObject.SetActive(true);
            return po.gameObject;
        }

        public void Release(PoolObj po)
        {
            if (!Allocated.Remove(po))
            {
                throw new System.Exception("cannot release un-pool game object!");
            }

            Cached.Add(po);
            po.transform.SetParent(_parentNode, false);
        }
        

        public void Destroy()
        {
            if (_parentNode != null)
            {
                _parentNode.gameObject.DestroyGameObject();
                Cached.Clear();

                Allocated.ForEach(po => po.gameObject.DestroyGameObject());
                Allocated.Clear();

                _parentNode = null;
            }            
        }
        
        public override string ToString()
        {
            return _name;
        }

    }
}