﻿using System.Collections.Generic;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace Commando.Res
{
    public class PreloadConfig
    {
        public List<PreloadUnit> Scene = new List<PreloadUnit>();
        public List<PreloadUnit> Unit = new List<PreloadUnit>();

        public string Serialize()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented, new JsonSerializerSettings());
        }

        public static PreloadConfig Deserialize(string json)
        {
            json = (new Regex("//.*")).Replace(json, "");
            return (PreloadConfig)JsonConvert.DeserializeObject(json, typeof(PreloadConfig));
        }
    }

    public class PreloadUnit
    {
        public string SrcFile;
        public int UnitId;
        public List<PreloadUnitList> ManualPreloadList = new List<PreloadUnitList>();
        public List<PreloadUnitList> AutoPreloadList = new List<PreloadUnitList>();        
    }

    public class PreloadUnitList
    {
        public string Name;
        public int InstantiateCount = 1;

        public override string ToString()
        {
            return "preload [" + Name + "] instantiate count: " + InstantiateCount;
        }
    }
}
