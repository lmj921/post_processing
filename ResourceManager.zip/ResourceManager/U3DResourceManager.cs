﻿using System.Collections.Generic;
using Commando.AssetBundles;
using UnityEngine;

namespace Commando.Res
{
    public class U3DResourceManager : ResourceManager
    {
        private Dictionary<string, ABMapping> _abMappingDict = new Dictionary<string, ABMapping>();

        public static readonly string ConfigPathFilename = "unit_preload_config";
        private PreloadConfig _preload;
        private readonly PoolManager _poolManager;

        public U3DResourceManager()
        {
            if (_instance != null)
            {
                throw new System.Exception("Please use ResourceManager.GetInstance() instead");
            }

            _poolManager = new PoolManager(name => LoadAsset<GameObject>(name), "default");

            LoadABMapping();
            LoadPreloadConfig();
        }

        private void LoadABMapping()
        {
            AssetBundleManager.Initialize();

            TextAsset mappingText = AssetBundleManager.LoadAsset<TextAsset>("abmapping", "abMappingJson");
            ABMappingList abMappingList = JsonUtility.FromJson<ABMappingList>(mappingText.text);
            for (int i = 0, max = abMappingList.mappingList.Count; i < max; i++)
            {
                ABMapping mapping = abMappingList.mappingList[i];
                //

                if(_abMappingDict.ContainsKey(mapping.assetName))
                {
                    Debug.LogWarning("_abMappingDict Contains--->" + mapping.assetName);
                }
                else
                {
                    _abMappingDict.Add(mapping.assetName, mapping);
                }
                
            }
        }

        private void LoadPreloadConfig()
        {
            TextAsset json = LoadAsset<TextAsset>("preload_config_json");
            _preload = PreloadConfig.Deserialize(json.text);
        }

        public sealed override T LoadAsset<T>(string assetName)
        {
            ABMapping mapping = null;
            if (_abMappingDict.TryGetValue(assetName, out mapping))
            {
                return AssetBundleManager.LoadAsset<T>(mapping.assetBundleName, assetName);
            }
            else
            {
                throw new System.Exception(string.Format("Please add this resource [{0}] into ab mapping by AssetBundle Browser", assetName));
            }
        }

        public sealed override T[] LoadAllAssetFromAssetBundle<T>(string assetBundleName)
        {
            return AssetBundleManager.LoadAllAssets<T>(assetBundleName);
        }

        public sealed override string[] GetAssetNamesFromAssetBundle(string assetName)
        {
            return AssetBundleManager.GetAssetNamesFromAssetBundle(assetName);
        }

        public sealed override void InitFightPreload(List<int> unitIds)
        {
            return;

            _poolManager.DestroyAll();

            System.Action<PreloadUnitList> loadDele = u =>
            {
                try
                {
                    _poolManager.AddPrefab(u.Name, LoadAsset<GameObject>(u.Name), u.InstantiateCount);
                }
                catch (System.Exception e)
                {
                    CLog.Exception(string.Format("{0} preload error : {0}", u, e.Message));
                }
            };

            // prepare the pool manager by prelad config
            System.Action<PreloadUnit> listDele = list =>
            {
                if (unitIds.Contains(list.UnitId))
                {
                    if (list.AutoPreloadList != null)
                    {
                        list.AutoPreloadList.ForEach(loadDele);
                    }
                    if (list.ManualPreloadList != null)
                    {
                        list.ManualPreloadList.ForEach(loadDele);
                    }
                }                
            };

            _preload.Scene.ForEach(listDele);
            _preload.Unit.ForEach(listDele);
        }

        public override void LoadPrefabToPool(string assetName, int initCount=0)
        {
            ABMapping mapping = null;
            if (_abMappingDict.TryGetValue(assetName, out mapping))
            {              
                GameObject prefab = LoadAsset<GameObject>(assetName);
                if (initCount==0)
                {
                    initCount = mapping.initCount;
                }
                _poolManager.AddPrefab(assetName, prefab, initCount);
            }
        }

        public override void AddGameObjectToPool(string poolName, GameObject go)
        {
            _poolManager.AddGameObject(poolName, go);
        }

        public override GameObject GetGameObjectFromPool(string prefabName)
        {
            return _poolManager.Fetch(prefabName);
        }

        public sealed override void ClearFightPreload()
        {
            _poolManager.DestroyAll();
        }

        public sealed override GameObject PlayFX(string fxPrefabName, Vector3 postion, Quaternion rotation, Vector3 scale, IPuppetView parentPuppetView, float duration)
        {

#if (UNITY_ANDROID || UNITY_STANDALONE_WIN) && DEVELOPMENT_BUILD
            UWAEngine.PushSample("U3DResourceManager.PlayFX");
#endif

            GameObject obj = FetchPreloadInst(fxPrefabName);

            //TODO 不能每次都go.GetComponent<AutoDestroyPrefab>();
            if (duration>0)
            {
                AutoDestroyPrefab.GetAndReset(obj, duration).DestroyDele = (go) =>
                    {
                        if (parentPuppetView != null){
                            parentPuppetView.RemoveChildFromPool(obj);
                        }
                        ReleasePreloadInst(go);
                    };
            }

            if (parentPuppetView != null)
            {
                obj.transform.parent = parentPuppetView.transform;
                if (duration>0)
                {
                    parentPuppetView.AddChildFromPool(obj);    
                }
            }

            obj.transform.localPosition = postion;
            obj.transform.localRotation = rotation;
            obj.transform.localScale    = scale;

#if (UNITY_ANDROID || UNITY_STANDALONE_WIN) && DEVELOPMENT_BUILD
            UWAEngine.PopSample();
#endif
            return obj;
        }

        public sealed override GameObject FetchPreloadInst(string name)
        {
#if (UNITY_ANDROID || UNITY_STANDALONE_WIN) && DEVELOPMENT_BUILD
            UWAEngine.PushSample("U3DResourceManager.FetchPreloadInst");
#endif

            try
            {
                GameObject go = _poolManager.Fetch(name);
                return go;
            }
            finally
            {
#if (UNITY_ANDROID || UNITY_STANDALONE_WIN) && DEVELOPMENT_BUILD
                UWAEngine.PopSample();
#endif
            }
        }

        public sealed override void ReleasePreloadInst(GameObject go)
        {
            _poolManager.Release(go);
        }

        public override void ReleaseAllAssets()
        {
            AssetBundleManager.UnloadAllMainAssetBundle();
        }
    }
}