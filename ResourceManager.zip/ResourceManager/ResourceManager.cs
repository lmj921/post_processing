﻿using System.Collections.Generic;
using Commando.AssetBundles;
using UnityEngine;

namespace Commando.Res
{
    public abstract class ResourceManager
    {
        protected static ResourceManager _instance;

        protected ResourceManager()
        {
        }

        public static ResourceManager GetInstance()
        {
            if (_instance == null)
            {
#if (!NETCOREAPP2_0)
                _instance = new U3DResourceManager();
#else
                _instance = new NullResourceManager();
#endif
            }

            return _instance;
        }

        public virtual T LoadAsset<T>(string assetName) where T : Object
        {
            return default(T);
        }            

        public virtual T[] LoadAllAssetFromAssetBundle<T>(string assetBundleName) where T : Object
        {
            return default(T[]);
        }

        public virtual string[] GetAssetNamesFromAssetBundle(string assetName)
        {
            return null;
        }

        /// <summary>
        /// initialize the fight(battle) scene and pre-load all unit by definition unit id
        /// </summary>
        /// <param name="unitIds"></param>
        public virtual void InitFightPreload(List<int> unitIds)
        {
        }

        public virtual void LoadPrefabToPool(string assetName, int initCount=0)
        {
        }

        public virtual void AddGameObjectToPool(string poolName, GameObject go)
        {
        }

        public virtual GameObject GetGameObjectFromPool(string prefabName)
        {
            return null;
        }

        public virtual void ClearFightPreload()
        {
        }


        /// <summary>
        /// Play a FX which can be destroy itself automatically
        /// </summary>
        /// <param name="fxPrefabName"></param>
        public virtual GameObject PlayFX(string fxPrefabName, Vector3 postion, Quaternion rotation, Vector3 scale, IPuppetView parentPuppetView, float duration)
        {
            return null;
        }

        /// <summary>
        /// load preload instance which in pool manager
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public virtual GameObject FetchPreloadInst(string name)
        {
            return null;
        }

        /// <summary>
        /// release preload instance to the pool manager
        /// </summary>
        /// <param name="go"></param>
        public virtual void ReleasePreloadInst(GameObject go)
        {
        }

        public virtual void ReleaseAllAssets()
        {

        }
    }
}